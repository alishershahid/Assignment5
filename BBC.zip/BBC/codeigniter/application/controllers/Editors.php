<?php
class Editors extends CI_Controller{
    function index(){
        $this->load->model('Editor');
        $editor=$this->Editor->all();
        $data = array();
        $data['editor'] = $editor;
        $this->load->view('list', $data);
    }

    function create(){
        $this->load->model('Editor');
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required');
        
        if($this->form_validation->run()==false)
        {
            $this->load->view('create');
        }
        else{
            $formData = array();
            $formData['username']=$this->input->post('username');
            $formData['email']=$this->input->post('email');
            $formData['password']=$this->input->post('password');
            $this->Editor->create($formData);
            $this->session->set_flashdata('success', 'Record added successfully');
            redirect(base_url().'index.php/Editors/create');
        }
    }
    function edit($id)
    {
        $this->load->model('Editor');
        $editors = $this->Editor->getUser($id);
        $data = array();
        $data['editors']=$editors;

        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');

        if($this->form_validation->run()==false)
        {
            $this->load->view('edit', $data);
        }
        else{
            $formArray = array();
            $formArray['username']=$this->input->post['username'];
            $formArray['email']=$this->input->post['email'];
            $this->Editor->updateUser($id, $formArray);
            $this->session->set_flashdata('success', 'Record Updated successfully');
            redirect(base_url().'index.php/Editors/index');
        }

       
    }

    function delete($username)
    {
        $this->load->model('Editors');
        $editors = $this->Editor->getUser($username);
        if(empty($editor)){
            $this->session->set_flashdata('failure', 'Record not found in database');
            redirect(base_url().'index.php/Editors/index');
        }
        else{
            $this->Editor->deleteUser($username);
            $this->session->set_flashdata('success', 'Record Deleted successfully');
            redirect(base_url().'index.php/Editors/index');
        }
    }
}
?>