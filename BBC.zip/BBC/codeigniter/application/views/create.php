<!DOCTYPE html>
<html lang="en">
<head>
    <title>Create Editor</title>
    <link rel="stylesheet" href="<?php echo base_url().'assets/css/bootstrap.min.css'?>">
</head>
<body>
    <!--Top Navbar-->
    <div class="navbar navbar-dark bg-dark">
        <div class="container">
            <a href="#" class="navbar-brand">CREATE EDITOR</a>
        </div>
    </div>
    <!--Form-->
    <div class="container" style="padding-top:20px;">
        <form method="POST" name="createUser" action="<?php echo base_url().'index.php/Editors/create';?>">
            <div class="row">
                
                <div class="col-md-6">

                    <div class="form-group">
                        <label>Username: </label>
                        <input value="<?php echo set_value('username')?>" type="text" name="username" class="form-control">
                        <?php echo form_error('username');?>
                    </div>

                    <div class="form-group">
                        <label>Email: </label>
                        <input value="<?php echo set_value('email')?>" type="text" name="email" class="form-control">
                        <?php echo form_error('email');?>
                    </div>

                    <div class="form-group">
                        <label>Password: </label>
                        <input value="<?php echo set_value('password')?>" type="password" name="password" class="form-control">
                        <?php echo form_error('password');?>
                    </div>

                    <div class="form-group">
                        <button class="btn btn-primary">Create</button>
                        <a class="btn btn-secondary" href="<?php echo base_url().'index.php/Editors/create';?>">Cancel</a>
                    </div>
                </div>

            </div>
        </form>
    </div>

</body>
</html>