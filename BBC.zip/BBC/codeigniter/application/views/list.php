<!DOCTYPE html>
<html lang="en">
<head>
    <title>Editors Record</title>
    <link rel="stylesheet" href="<?php echo base_url().'assets/css/bootstrap.min.css'?>">
</head>
<body>
    <!--Top Navbar-->
    <div class="navbar navbar-dark bg-dark">
        <div class="container">
            <a href="#" class="navbar-brand">VIEW EDITORS</a>
        </div>
    </div>
    <!--Form-->
    <div class="container" style="padding-top:20px;">
       
        <div class="row">

            <div style="padding-bottom:20px;" class="col-md-6">
            <a class="btn btn-primary" href="<?php echo base_url().'index.php/Editors/create'?>">Create User</a>
            </div>

            <div class="col-md-8">
                <table class="table table-striped">
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>

                    <?php if(!empty($editor))  {foreach($editor as $editors) { ?>
                    <tr>
                        <td><?php echo $editors['id']?></td>
                        <td><?php echo $editors['username'] ?></td>
                        <td><?php echo $editors['email'] ?></td>
                        <td>
                            <a class="btn btn-primary" href="<?php echo base_url(). 'index.php/Editors/edit/'.$editors['username']?>">Edit</a>
                        </td>
                        <td>
                            <a class="btn btn-danger" href="<?php echo base_url(). 'index.php/Editors/delete/'.$editors['email']?>">Delete</a>
                        </td>
                    </tr>  
                   

                    <?php   }} else{?>
                
                        <tr>
                            <td>Records not found</td>
                        </tr>

                    <?php } ?>

                </table>
            </div>
        </div>

    </div>

    </body>

    </html>