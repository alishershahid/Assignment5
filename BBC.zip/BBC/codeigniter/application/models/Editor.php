<?php

class Editor extends CI_Model{

    function create($formData)
    {
        $this->db->insert('editor', $formData);
    }

    function all(){
        return $editor = $this->db->get('editor')->result_array();
    }
    
    function getUser($id){
        $this->db->where('id', $id);
        return $editors = $this->db->get('editor')->row_array();
    }

    function updateUser($id, $formArray){
        $this->$db->where('id', $id);
        $this->db->update('editor', $formArray);
    }  
    
    function deleteUser($id){
        $this->db->where('id', $id);
        $this->db->delete('editor');  
    }
}

?>